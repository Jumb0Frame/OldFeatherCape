# Old Feather Cape

Big Potion went after the Feather Cape, we won't stand for it! \
This mod allows you to craft a modified version of the "Feather Cape" called "Old Feather Cape" which has the +20% jump height that got taken away with the Bog Witch update. Use the Galdr table to craft it.

## Installation (manual)

Grab the OldFeatherCape.dll file and place it in your Bepinex plugins folder

If you do multiplayer on a dedicated server, everyone and the server need the plugin (Bepinex and Jotunn as well)

## Features

This mod allows you to craft a modified Feather Cape called Old Feather Cape. \
This Old Feather Cape has the +20% jump height bonus back on it (including the other Feather Cape effects). \
This modified cape is craftable at the Galdr table.

## Known issues

If you would encounter any issue, you can find the github at: https://github.com/Jumb0Frame/OldFeatherCape \
Please open an issue there and explain what problem you encountered
