# Old Feather Cape

Big Potion went after the Feather Cape, we won't stand for it!

## Installation (manual)

Grab the OldFeatherCape.dll file and place it in your Bepinex plugins folder

If you do multiplayer on a dedicated server, everyone and the server need the plugin (Bepinex and Jotunn as well)

## Features

Puts the +20% jump height boost back on the Feather Cape

## Known issues

If you would encounter any issue, you can find the github at: https://github.com/Jumb0Frame/OldFeatherCape \
Please open an issue there and explain what problem you encountered
