# Changelog

## Version 1.0.7
* And updated the changelog to indicate that the mod has been update for Valheim 1.0...

## Version 1.0.6
* Updated for Valheim 1.0

## Version 1.0.5
* Minor fix (removed warnings being thrown in the logs)

## Version 1.0.4
* Updated mod description in the manifest

## Version 1.0.3
* Updated readme and descriptions to clarify what the mod does

## Version 1.0.2
* Fix jump height bonus not being applied because of the latest game patch

## Version 1.0.1
* Update readme

## Version 1.0.0
* Feather cape with the +20% jump height added back as a set effect