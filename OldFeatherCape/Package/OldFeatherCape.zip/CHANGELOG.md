# Changelog

## Version 1.0.2
* Fix jump height bonus not being applied because of the latest game patch

## Version 1.0.1
* Update readme

## Version 1.0.0
* Feather cape with the +20% jump height added back as a set effect